export class Contact {
    customer_name!: string;
    customer_email!: string;
    customer_message!:string;
}
