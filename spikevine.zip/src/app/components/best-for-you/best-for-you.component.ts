import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-best-for-you',
  templateUrl: './best-for-you.component.html',
  styleUrls: ['./best-for-you.component.css']
})
export class BestForYouComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
